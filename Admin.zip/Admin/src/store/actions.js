
//给 action 注册事件处理函数。当这个函数呗触发的时候  将状态提交到mutations中处理
export function changeList({commit},name){   //方法
	return commit ('leftList',name)
}