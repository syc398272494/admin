// import Vue from 'vue';
// import Vuex from 'vuex';
// import * as getters from './getters' // 导入响应的模块，*相当于引入了这个组件下所有导出的事例
// import * as actions from './actions'
// import * as mutations from './mutations'

// Vue.use(Vuex );//使用Vuex
// //创建一个常量对象
// const state={
//     allDept:[]
// }

// // 注册上面引入得各大模块
// const store=new Vuex.Store({
// 	state, //共同维护得一个状态，state里面可以是很多个全局状态
// 	getters, //获取数据并渲染
// 	actions, //数据得异步操作
// 	mutations  //处理数据唯一得途径，state得改变或赋值  只能在这里
// })

// //让外部引用vuex
// export default store  //导出store并在 main.js中引入注册


import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {  //存储应用中需要共享的状态，为了能让 Vue 组件在 state更改后也随着更改，需要基于state在组件中创建计算属性computed。
    allDept: '',
  },
  mutations: {  //改变状态的执行者，用于同步的更改状态
    "SET_MSG": function (state, allDept) {
      state.allDept = allDept
    }
  },
  getters: {  //类似于Vue中的计算属性,可以在其他state或者getter改变后自动改变。每个getter方法接受 state和其他getters作为前两个参数。
    GET_MSG: state => state.allDept
  },
  actions: { //想要异步地更改状态,需要使用action。action并不直接改变state而是发起mutation
    "SET_MSG": function (state, allDept) {
      store.commit("SET_MSG", allDept)
    }
  }
})
export default store
