import Vue from 'vue';
import Vuex from 'vuex';
import * as getters from './getters' // 导入响应的模块，*相当于引入了这个组件下所有导出的事例
import * as actions from './actions'
import * as mutations from './mutations'

Vue.use(Vuex );//使用Vuex 
//创建一个常量对象
const state={
    leftList:[
        {
            icon: 'el-icon-news',
            index: 'dashboard',
            title: '首页'
        },
        {
            icon: 'el-icon-document',
            index: '2',
            title: '系统设置',
            subs:[
                {
                    index:"setup",
                    title:"菜单管理"
                }
            ]
        }
    ]
}

// 注册上面引入得各大模块
const store=new Vuex.Store({
	state, //共同维护得一个状态，state里面可以是很多个全局状态
	getters, //获取数据并渲染
	actions, //数据得异步操作
	mutations  //处理数据唯一得途径，state得改变或赋值  只能在这里
})

//让外部引用vuex
export default store  //导出store并在 main.js中引入注册