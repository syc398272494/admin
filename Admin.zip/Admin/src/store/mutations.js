// 提交  mutations是更改 Vuex状态的唯一合法方法
export const changeList=(state,name)=>{
	state.allDept=name
}