
export const leftList=state =>state.leftList