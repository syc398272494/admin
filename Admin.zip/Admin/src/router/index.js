import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [
  {
      path: '/',
      redirect: '/dashboard'
    },
    {
      path: '/login',
      name: 'login',
      component: resolve => require(['../views/login/login.vue'], resolve),//懒加载
    },
    {
      path: '/',
      name: 'home',
      component: resolve => require(['../components/common/home.vue'], resolve),
       children:[
        {
            path: '/dashboard',
            name: 'dashboard',
            component: resolve => require(['../views/dashboard/Dashboard.vue'], resolve),
            meta: { title: '首页'}
        },
        {
            path: '/setup',
            name: 'setup',
            component: resolve => require(['../views/system/setup/setup.vue'], resolve),
            meta: { title: '菜单管理' }
        },
          {
            path: '/organi',
            name: 'organi',
            component: resolve => require(['../views/system/organi/organi.vue'], resolve),
            meta: { title: '组织架构' }
        },
        {
            path: '/role',
            name: 'role',
            component: resolve => require(['../views/system/role/role.vue'], resolve),
            meta: { title: '角色管理' }
        },
        {
            path: '/userMent',
            name: 'userMent',
            component: resolve => require(['../views/system/userMent/userMent.vue'], resolve),
            meta: { title: '用户管理' }
        },

        {
            path: '/notice',
            name: 'notice',
            component: resolve => require(['../views/appAdmin/notice/notice.vue'], resolve),
            meta: { title: '通知公告' }
        },
        {
            // 富文本编辑器组件
            path: '/active',
            name: 'active',
            component: resolve => require(['../views/appAdmin/active/active.vue'], resolve),
            meta: { title: '活动列表' }
        }
      ]
    }
  ]
})

