import request from '@/units/request'

export function login (data) {
  return request({
    url: '/api/admin/login/getToken',
    method: 'post',
    data: data
  })
}
