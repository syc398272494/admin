import request from '@/units/request'

export function getMenu (data) {//获取菜单
  return request({
    url: '/api/admin/menu/GetAllMenu',
    method: 'post',
    data: data
  })
}

export function addRole (data) {//获取角色
  return request({
    url: '/api/admin/role/add',
    method: 'post',
    data: data
  })
}

export function getRoleLists (data) {//获取角色
  return request({
    url: '/api/admin/role/getList',
    method: 'post',
    data: data
  })
}

export function roleDetail (data) {//获取角色详情
  return request({
    url: '/api/admin/role/GetDetails',
    method: 'post',
    data: data
  })
}

export function updateRole (data) {//修改角色
  return request({
    url: '/api/admin/role/edit',
    method: 'post',
    data: data
  })
}

export function deleteRole (data) {//删除角色
  return request({
    url: '/api/admin/role/del',
    method: 'post',
    data: data
  })
}
