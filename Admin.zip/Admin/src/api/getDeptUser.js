import request from '@/units/request'

export function getDepts (data,url) {   //获取部门数据
  return request({
    url: url,
    method: 'post',
    data: data
  })
}

export function getUsers (data,url) {   //获取人员数据
  return request({
    url: url,
    method: 'post',
    data: data
  })
}