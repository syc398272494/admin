import request from '@/units/request'

export function addMenu (data) {//添加表单
  return request({
    url: '/api/admin/menu/add',
    method: 'post',
    data: data
  })
}
export function updateMenuData (data) {//修改菜单
  return request({
    url: '/api/admin/menu/edit',
    method: 'post',
    data: data
  })
}
export function menudelete (data) {//删除
  return request({
    url: '/api/admin/menu/del',
    method: 'post',
    data: data
  })
}
export function MenuList (data) {//获取菜单列表接口
  return request({
    url: '/api/admin/menu/GetChildrenList',
    method: 'post',
    data: data
  })
}
export function getMenuData (data) {//获取单个菜单信息
  return request({
    url: '/api/admin/menu/get',
    method: 'post',
    data: data
  })
}
export function queryForm () {//表单查询
  return request({
    url: '',
    method: 'post',
    data: data
  })
}
