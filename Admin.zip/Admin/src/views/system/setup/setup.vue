<template>
  <div class="dashboard">
    <div class="setupHead">
      <div>
        <el-button type="primary" @click="addForm(1)">添加</el-button>
        <el-button type="info" @click="returnPage" v-if="backBtnStatus">返回</el-button>
      </div>
      <div class="dashboard-search">
        <el-form :inline="true" class="demo-form-inline dashboard-form">
          <el-form-item label="" style="margin-bottom: 0">
            <el-input style="height: 30px;line-height: 30px" v-model="keyWords" placeholder="请输入内容"></el-input>
          </el-form-item>
          <el-form-item style="margin: 0">
            <el-button type="primary" @click="onCheckSubmit">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div>
      <el-table
        v-loading="loadingForm"
        element-loading-text="数据加载中...."
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
        ref="multipleTable"
        :data="tableData3.slice((currentPage-1)*pagesize,currentPage*pagesize)"
        tooltip-effect="dark"
        stripe
        style="width: 100%"
        max-height="400">
        <el-table-column
          prop="MenuName"
          label="菜单名称"
          header-align="center"
          width="120">
        </el-table-column>
        <el-table-column
          prop="MenuUrl"
          header-align="center"
          label="菜单地址"
          width="300">
        </el-table-column>
        <el-table-column
          prop="OrderNo"
          header-align="center"
          label="排序"
          width="150">
        </el-table-column>
        <el-table-column
          label="操作"
          header-align="center"
          show-overflow-tooltip>
          <template slot-scope="scope" v-if="tableData3.length!=0">
            <el-button type="primary" size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
            <el-button type="success" size="mini" @click="handleEditManageSubpages(scope.$index, scope.row)">管理子页面
            </el-button>
            <el-button type="danger" size="mini" @click="handleEditdelete(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block pageContent">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[10, 20, 30, 40]"
          :page-size="pagesize"
          layout="total, sizes, prev, pager, next, jumper"
          :total=tableData3.length>
        </el-pagination>
      </div>
    </div>
    <!--添加菜单model-->
    <el-dialog
      title="管理菜单"
      :visible.sync="addDialogVisible"
      width="50%">
      <div class="memberDialog-formBox">
        <el-form :model="formInlineMember" :rules="rules" :hide-required-asterisk="true" ref="formInlineMember"
                 label-width="80px" class="demo-ruleForm">
          <div class="member-form">
            <el-form-item label="菜单名称" prop="menuName">
              <el-input v-model="formInlineMember.menuName" placeholder="菜单名称"></el-input>
            </el-form-item>
          </div>
          <div class="member-form">
            <el-form-item label="菜单地址" prop="menuPlace">
              <el-input v-model="formInlineMember.menuPlace" placeholder="菜单地址"></el-input>
            </el-form-item>
          </div>
          <div class="member-form">
            <el-form-item label="排序" prop="menuOrder">
              <el-input v-model="formInlineMember.menuOrder" placeholder="排序"></el-input>
            </el-form-item>
          </div>
          <div class="member-form" style="text-align: right">
            <el-form-item>
              <el-button @click="canceladdDialog">取 消</el-button>
              <el-button type="primary" @click="submit('formInlineMember')">确 定</el-button>
            </el-form-item>
          </div>
        </el-form>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {addMenu, MenuList, getMenuData, updateMenuData, menudelete, queryForm} from '@/api/menuManagement'
  import bus from '@/assets/js/bus'
  import {mapActions, mapGetters} from 'vuex'

  export default {
    name: 'dashboard',
    data() {
      return {
        token: "",
        type: "",//1代表添加菜单，否则编辑菜单
        formid: "",//表单id
        parentFormid: "",//父级id
        keyWords: '', //查询搜索
        addDialogVisible: false,
        formInlineMember: {  //添加菜单
          menuName: "",//菜单名称
          menuPlace: "",//菜单地址
          menuOrder: "",//排序
        },
        rules: {
          menuName: [
            {required: true, message: '请输入菜单名称', trigger: 'blur'},
          ],
          menuPlace: [
            {required: true, message: '请输入菜单地址', trigger: 'blur'}
          ],
          menuOrder: [
            {required: true, message: '请输入排序', trigger: 'blur'}
          ]
        },
        tableData3: [],//表单数据
        loadingForm: false,//自定义加载
        currentPage: 1,//页数
        pagesize: 20,//条数
        pids: "",
        backBtnStatus: false
      }
    },
    mounted() {
      this.token = localStorage.getItem("admin");
      this.getMenuLists(0);

      var name="Jack";
      var obj={
        name:'Mary',
        getName:function(){
          return this.name
        }
      };
        console.log(obj.getName());
        var fucn=obj.getName;
      console.log(fucn);
      console.log(fucn.call(obj));

    },
    methods: {
      //搜索人员
      onCheckSubmit() {
        var _this = this;
        _this.loadingForm = true;
        console.log(_this.$route.query.pid);
        if (_this.$route.query.pid == undefined) {
          _this.getMenuLists(0);
        } else {
          _this.getMenuLists(_this.$route.query.pid);
        }

      },
      //编辑菜单
      handleEdit(index, row) {
        var _this = this;
        _this.type = 2
        _this.addDialogVisible = true;
        const data = {
          token: _this.token,//token
          id: row.Id,
        };
        console.log(row);
        getMenuData(data).then(res => {
          if (res.data.returncode == 0) {
            var data = JSON.parse(res.data.data);
            console.log(data);
            _this.formInlineMember.menuName = data.MenuName;
            _this.formInlineMember.menuPlace = data.MenuUrl;
            _this.formInlineMember.menuOrder = data.OrderNo;
            _this.formid = data.Id;
            _this.parentFormid = data.ParentId;
            // console.log(_this.formid);
          }
        }).catch(error => {
        })
        _this.memberDialogVisible = true;
        console.log(index, row);
      },
      //获取菜单列表接口
      getMenuLists: function (pid) {
        var _this = this;
        console.log(pid);
        // console.log(this.$router.id);
        if (pid == 0) {
          const data = {
            token: _this.token,//token
            pid: 0,//菜单父级ID(如果是一级菜单传值0，如果是二级以及其它则传后台返回的pid)
            key: _this.keyWords,
            pageindex: _this.currentPage,
            pagesize: _this.pagesize,
          };
          MenuList(data).then(res => {
            if (res.data.returncode == 0) {
              var data = JSON.parse(res.data.data);
              console.log(data);
              _this.tableData3 = data;
            }
            _this.loadingForm = false;
          }).catch(error => {
          })
        } else {
          const data = {
            token: _this.token,//token
            pid: pid,//菜单父级ID(如果是一级菜单传值0，如果是二级以及其它则传后台返回的pid)
            key: _this.keyWords,
            pageindex: _this.currentPage,
            pagesize: _this.pagesize,
          };
          MenuList(data).then(res => {
            if (res.data.returncode == 0) {
              var data = JSON.parse(res.data.data);
              console.log(data);
              _this.tableData3 = data;
            }
            _this.loadingForm = false;
          }).catch(error => {
          })
        }
      },
      //添加清空按钮
      addForm: function (data) {
        var _this = this;
        _this.type = data;
        console.log(_this.type);
        _this.addDialogVisible = true;
        if (_this.type == 1) {
          _this.formInlineMember.menuName = "";
          _this.formInlineMember.menuPlace = "";
          _this.formInlineMember.menuOrder = "";
        }

        if (_this.backBtnStatus == false) {
          _this.formid = 0;
        }
      },
      //添加
      submit: function (formName) {
        var _this = this;
        _this.loadingForm = true;
        this.$refs[formName].validate((valid) => {
          if (valid) {
            console.log(_this.formid);
            var id = _this.formid;
            var parentId = _this.parentFormid;
            console.log(parentId);
            console.log(_this.type);
            if (_this.type == 1) {
              if (_this.backBtnStatus == false) {
                id = 0;
              }
              console.log(1111);
              if (id == "") {     // 添加一级菜单
                var data = {
                  token: _this.token,//token
                  name: _this.formInlineMember.menuName,//菜单名称
                  url: _this.formInlineMember.menuPlace,//菜单地址
                  pid: 0,//菜单父级ID(如果是一级菜单传值0，如果是二级以及其它则传后台返回的pid)
                  order: _this.formInlineMember.menuOrder,//菜单排序（正整数，小的排在前面）
                };
              } else if (id != "") {  //添加二级菜单
                var data = {
                  token: _this.token,//token
                  name: _this.formInlineMember.menuName,//菜单名称
                  url: _this.formInlineMember.menuPlace,//菜单地址
                  pid: id,//菜单父级ID(如果是一级菜单传值0，如果是二级以及其它则传后台返回的pid)
                  order: _this.formInlineMember.menuOrder,//菜单排序（正整数，小的排在前面）
                };
              }
              console.log(data);
              addMenu(data).then(res => {
                if (res.data.returncode == 0) {
                  if (_this.formid == 0) {
                    this.$router.push({
                      name: "setup",
                    });
                  } else {
                    this.$router.push({
                      name: "setup",
                      query: {
                        pid: _this.formid
                      }
                    });
                  }
                  _this.loadingForm = false;
                  _this.getMenuLists(_this.formid);
                  _this.addDialogVisible = false;
                  // console.log(res.data);
                  // _this.getMenuLists(parentId);
                  // _this.loadingForm=false;
                  this.$message({
                    message: '恭喜你，菜单创建成功!',
                    type: 'success'
                  });
                }
              }).catch(error => {
              })
            } else if (_this.type == 2) {
              console.log(222);
              const data = {  // 修改菜单
                token: _this.token,//token
                name: _this.formInlineMember.menuName,//菜单名称
                url: _this.formInlineMember.menuPlace,//菜单地址
                pid: parentId,//菜单父级ID(如果是一级菜单传值0，如果是二级以及其它则传后台返回的pid)
                order: _this.formInlineMember.menuOrder,//菜单排序（正整数，小的排在前面）
                id: id,
              };
              console.log(data);
              updateMenuData(data).then(res => {
                if (res.data.returncode == 0) {
                  _this.addDialogVisible = false;
                  _this.getMenuLists(parentId);
                  _this.loadingForm = false
                  this.$message({
                    message: '菜单修改成功!',
                    type: 'success'
                  });
                }
              }).catch(error => {
              })
            }
          } else {
            console.log('error submit!!');
            return false;
          }
        });
      },
      //删除菜单
      handleEditdelete(index, row) {
        var _this = this;
        this.$confirm('此操作将永久删除, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          const data = {
            token: _this.token,
            id: row.Id,
          };
          menudelete(data).then(res => {
            if (res.data.returncode == 0) {
              var data = JSON.parse(res.data.data);
              console.log(data);
            }
          }).catch(error => {
          });
          if (_this.backBtnStatus == false) {
            this.$router.push({
              name: "setup",
            });
            _this.loadingForm = true;
            _this.getMenuLists(0);
          } else if (_this.backBtnStatus == true) {
            this.$router.push({
              name: "setup",
              query: {
                pid: _this.formid
              }
            });
            _this.loadingForm = true;
            _this.getMenuLists(_this.formid);
          }

          this.$message({
            type: 'success',
            message: '删除成功!'
          });
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          });
        });
      },
      //管理子页面
      handleEditManageSubpages(index, row) {
        var _this = this;
        _this.backBtnStatus = true;
        // console.log(row.Id);
        const data = {
          token: _this.token,//token
          id: row.Id,
        };
        getMenuData(data).then(res => {
          if (res.data.returncode == 0) {
            var data = JSON.parse(res.data.data);
            _this.formid = data.Id;
            // console.log(_this.formid);
            this.$router.push({
              name: "setup",
              query: {
                pid: _this.formid
              }
            });
            _this.loadingForm = true
            _this.getMenuLists(_this.formid);
          }
        }).catch(error => {
        })
      },
      //分页
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
        var _this = this;
        _this.pagesize = val;
        _this.getMenuLists(0);
      },
      handleCurrentChange(val) {
        var _this = this;
        console.log(`当前页: ${val}`);
        _this.currentPage = val;
        _this.getMenuLists(0);
      },
      //返回
      returnPage() {
        this.$router.go(-1);
      },
      //取消
      canceladdDialog: function () {
        var _this = this;
        _this.loadingForm = false;
        _this.addDialogVisible = false;
      },
      setAd() {
        bus.$emit('seta', "张三");
      },
      setVue() {

        var leftList = [
          {
            icon: 'el-icon-news',
            index: 'dashboard',
            title: '首页1'
          },
          {
            icon: 'el-icon-document',
            index: '2',
            title: '系统设置1',
            subs: [
              {
                index: "setup",
                title: "菜单管理"
              }
            ]
          }
        ];
        bus.$emit('setItems', leftList);

      }
    },
    watch: {
      $route(to, from) {
        var _this = this;
        var id = to.query.pid;
        if (id == undefined) {
          _this.getMenuLists(0);
          _this.backBtnStatus = false;
        } else {
          _this.backBtnStatus = true
          _this.getMenuLists(id);
        }
      },
      keyWords: function (value) {
        var _this = this;
        console.log(value);
        console.log(_this.$route.query.pid);
        if (_this.backBtnStatus == false) {
          _this.getMenuLists(0);
        } else if (_this.backBtnStatus == true) {
          _this.getMenuLists(_this.$route.query.pid);
        }
      }
    },
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  .memberDialog-formBox {
    width: 100%;
  }

  .pageContent {
    text-align: right;
    margin-top: 10px;
  }

  .setupHead {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
  }
</style>
