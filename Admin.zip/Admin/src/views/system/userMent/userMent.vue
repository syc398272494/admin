<template>
  <div class="dashboard">
    用户管理
    <choose-Du></choose-Du>
  </div>
</template>

<script>
  import bus from '@/assets/js/bus'
  import {mapActions, mapGetters} from 'vuex'
export default {
  name: 'userMent',
  data () {
    return {
    }
  },
  mounted(){
  },
  methods:{
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
