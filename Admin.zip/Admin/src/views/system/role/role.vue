<template>
  <div class="dashboard">
    <div class="setupHead">
      <div>
        <el-button type="primary" @click="addingRoles(1)">添加</el-button>
      </div>
      <div class="dashboard-search">
        <el-form :inline="true" class="demo-form-inline dashboard-form">
          <el-form-item label="" style="margin-bottom: 0">
            <el-input style="height: 30px;line-height: 30px" v-model="keyWords" placeholder="请输入内容"></el-input>
          </el-form-item>
          <el-form-item style="margin: 0">
            <el-button type="primary" @click="onCheckSubmit">查询</el-button>
          </el-form-item>
        </el-form>
      </div>
    </div>
    <div class="tables">
      <el-table
        v-loading="loadingForm"
        element-loading-text="数据加载中...."
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
        ref="multipleTable"
        :data="tableData.slice((currentPage-1)*pagesize,currentPage*pagesize)"
        tooltip-effect="dark"
        stripe
        style="width: 100%">
        <el-table-column
          prop="RoleName"
          label="角色名称"
          width="180">
        </el-table-column>
        <el-table-column
          prop="Description"
          label="角色描述"
          width="180">
        </el-table-column>
        <el-table-column
          prop="CreateTime"
          label="创建时间">
        </el-table-column>
        <el-table-column
          label="操作"
          header-align="center"
          show-overflow-tooltip>
          <template slot-scope="scope" v-if="tableData.length!=0">
            <el-button type="primary" size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
            <el-button type="danger" size="mini" @click="deleteEdit(scope.$index, scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <div class="block pageContent">
        <el-pagination
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
          :current-page="currentPage"
          :page-sizes="[10, 20, 30, 40]"
          :page-size=pagesize
          layout="total, sizes, prev, pager, next, jumper"
          :total=tableData.length>
        </el-pagination>
      </div>
    </div>
    <!--添加角色model-->
    <el-dialog
      title="管理菜单"
      :visible.sync="addDialogVisible"
      width="50%">
      <div class="memberDialog-formBox">
        <el-form :model="formInlineMember" :rules="rules" :hide-required-asterisk="true" ref="formInlineMember"
                 label-width="80px" class="demo-ruleForm">
          <div class="member-form">
            <el-form-item label="角色名称" prop="roleName">
              <el-input v-model="formInlineMember.roleName" placeholder="角色名称"></el-input>
            </el-form-item>
          </div>
          <div class="member-form">
            <el-form-item label="角色描述" prop="roleDescribe">
              <el-input v-model="formInlineMember.roleDescribe" placeholder="角色描述"></el-input>
            </el-form-item>
          </div>
          <div class="member-form">
            <el-form-item label="功能模块" prop="type">
              <!--:default-checked-keys="checkIds"-->
              <el-tree
                :data="munuData"
                show-checkbox
                node-key="id"
                :default-checked-keys="checkIds"
                ref="tree"
                highlight-current
                :props="defaultProps">
              </el-tree>

            </el-form-item>
          </div>
          <div class="member-form" style="text-align: right">
            <el-form-item>
              <el-button @click="canceladdDialog">取 消</el-button>
              <el-button type="primary" @click="submit('formInlineMember')">确 定</el-button>
            </el-form-item>
          </div>
        </el-form>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {getMenu,addRole,getRoleLists,updateRole,deleteRole,roleDetail} from '@/api/role'
export default {
  name: 'dashboard',
  data () {
    return {
      token:"",
      type:"",//1代表添加角色，否则编辑角色
      keyWords: '', //查询搜索
      tableData: [],
      currentPage: 1,//页数
      pagesize: 20,//条数
      loadingForm:false,//自定义加载
      addDialogVisible: false,
      munuData: [],//菜单列表
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      formInlineMember: {
        roleName: "",//角色名称
        roleDescribe: "",//角色描述
      },
      rules: {
        roleName: [
          {required: true, message: '请输入角色名称', trigger: 'blur'},
        ],
        roleDescribe: [
          {required: true, message: '请输入角色描述', trigger: 'blur'}
        ],
      },
      checkIds:[],//默认被选
      roleId:"",
    }
  },
  mounted(){
    this.token = localStorage.getItem("admin");
    this.getMenuLists(); //功能列表菜单获取
    this.getRoleList();  //获取角色列表
  },
  methods:{
    //获取角色列表
    getRoleList:function(){
      var _this=this;
      const data={
        token:_this.token,
        key:"",
        pageindex: _this.currentPage,
        pagesize:_this.pagesize,
      }
      getRoleLists(data).then(res => {
        if(res.data.returncode==0){
          var data=JSON.parse(res.data.data);
          console.log(data);
          _this.tableData=data;
        }
        _this.loadingForm=false;
      }).catch(error => {
      })
    },
    //功能列表菜单获取
    getMenuLists:function(){
      var _this=this;
      const data={
        token:_this.token
      }
      getMenu(data).then(res => {
        if(res.data.returncode==0){
          var data=JSON.parse(res.data.data);
          console.log(data);
          _this.munuData=data;
        }
        _this.loadingForm=false;
      }).catch(error => {
      })
    },
    //查询
    onCheckSubmit:function(){

    },
    //取消
    canceladdDialog:function(){
      this.$refs.tree.setCheckedKeys([]);
      this.addDialogVisible=false;
    },
    //添加
    submit: function (formName) {
      var _this = this;
      var menuids = this.getCheckedKeys(this.munuData, this.$refs.tree.getCheckedKeys(), 'id');
      console.log(menuids);
      var menuIds=menuids.toString();
      _this.loadingForm=true;
      this.$refs[formName].validate((valid) => {
        if (valid) {
          console.log(_this.type);
          if(_this.type==1){
              var data = {
                token: _this.token,
                name: _this.formInlineMember.roleName,
                description: _this.formInlineMember.roleDescribe,
                menuids:menuIds,
              };
            console.log(1111);
            console.log(data);
            addRole(data).then(res => {
                if (res.data.returncode == 0) {
                  console.log(res.data);
                  _this.addDialogVisible=false;
                  this.$message({
                    message: '角色添加成功!',
                    type: 'success'
                  });
                  _this.getRoleList();
                }
              }).catch(error => {
              })
            }else  if(_this.type==2){
              var data = {
                token: _this.token,
                roleid:_this.roleId,
                name: _this.formInlineMember.roleName,
                description: _this.formInlineMember.roleDescribe,
                menuids:menuIds,
              };
            console.log(222);
            console.log(data);
              updateRole(data).then(res => {
                if (res.data.returncode == 0) {
                  console.log(res.data);
                  _this.addDialogVisible=false;
                  this.$message({
                    message: '角色修改成功!',
                    type: 'success'
                  });
                  _this.getRoleList();
                }
              }).catch(error => {
              })
            }
          this.$refs.tree.setCheckedKeys([]);
        } else {
          console.log('error submit!!');
          return false;
        }
      });
    },
    //element-ui中el-tree树形控件-树节点的选择(选中当前节点,获取当前id并且获取其父级id)
    getCheckedKeys (data, keys, key) {
      var res = [];
      recursion(data, false);
      return res;
      // arr -> 树形总数据
      // keys -> getCheckedKeys获取到的选中key值
      // isChild -> 用来判断是否是子节点
      function recursion (arr, isChild) {
        var aCheck = [];
        for ( var i = 0; i < arr.length; i++ ) {
          var obj = arr[i];
          aCheck[i] = false;
          if ( obj.children ) {
            aCheck[i] = recursion(obj.children, true) ? true : aCheck[i];
            if ( aCheck[i] ) {
              res.push(obj[key]);
            }
          }
          for ( var j = 0; j < keys.length; j++ ) {
            if ( obj[key] == keys[j] ) {
              aCheck[i] = true;
              if ( res.indexOf(obj[key]) == -1 ) {
                res.push(obj[key]);
              }
              break;
            }
          }
        }
        if ( isChild ) {
          return aCheck.indexOf(true) != -1;
        }
      }
    },
    //编辑菜单
    handleEdit(index, row) {
      var _this=this;
      _this.addDialogVisible=true;
      _this.type = 2;
      const data={
        token:_this.token,
        roleid:row.Id
      }
      roleDetail(data).then(res=>{
         if(res.data.returncode==0){
           var data=JSON.parse(res.data.data);
           console.log(data);
           _this.formInlineMember.roleName=data.RoleName;
           _this.formInlineMember.roleDescribe=data.Description;
           console.log(data.MenuIdList);
           // _this.checkIds=data.MenuIdList;
           // _this.checkIds=[247,185,166];247,258,185,166
          //var arr=[247,258,]   //返回我选中的checkbox的id
          //  this.$refs.tree.setCheckedKeys(data.MenuIdList);
           _this.$nextTick(function () {
             this.$refs.tree.setCheckedKeys(data.MenuIdList);
           })
           _this.roleId=data.Id;
         }
      }).catch(error=>{

      })
    },
    //以下部分是回显时,将只有部分选择子节点的父节点剔除



    //添加角色
    addingRoles(type){
      this.type=type;
      this.formInlineMember.roleName="";
      this.formInlineMember.roleDescribe="";
      this.addDialogVisible=true;
    },
    //删除角色
    deleteEdit(index, row) {
      var _this = this;
      this.$confirm('此操作将永久删除, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        const data = {
          token: _this.token,
          id: row.Id,
        };
        deleteRole(data).then(res => {
          if (res.data.returncode == 0) {

          }
        }).catch(error => {
        });
        _this.loadingForm = true;

        _this.getRoleList();

        this.$message({
          type: 'success',
          message: '删除成功!'
        });
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        });
      });
    },
    //分页
    handleSizeChange(val) {
      var _this=this;
      console.log(`每页 ${val} 条`);
      _this.pagesize = val;
      _this.getRoleList();
    },
    handleCurrentChange(val) {
      var _this=this;
      console.log(`当前页: ${val}`);
      _this.currentPage = val;
      _this.getRoleList();
    },
  },
  watch:{
    addDialogVisible:function (value) {
      console.log(value);
      if(value==false){
        this.$refs.tree.setCheckedKeys([]);
      }
    }
  },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  .setupHead{
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
  }
  .pageContent{
    text-align: right;
    margin-top: 10px;
  }
</style>
