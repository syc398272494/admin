<template>
  <div class="dashboard">
     <div class="dashboard-head">
       <!--人员通讯录-->
       <h2 class="dashboard-title"></h2>
       <div class="dashboard-search">
         <el-form :inline="true" :model="formInline" class="demo-form-inline dashboard-form">
           <el-form-item label="" style="margin-bottom: 0">
             <el-input style="height: 30px;line-height: 30px" v-model="formInline.content" placeholder="请输入内容"></el-input>
           </el-form-item>
           <el-form-item style="margin: 0">
             <el-button type="primary" @click="onSubmit">查询</el-button>
           </el-form-item>
         </el-form>
       </div>
     </div>
     <div class="dashboard-box">
       <!--部门-->
       <div class="dashboard-left">
         <div class="dashboard-left-title">
           组织架构
           <span style="color: rgb(20, 106, 168);">添加</span>
           <span style="color: rgb(34, 193, 55);">编辑</span>
           <span style="color: rgb(255, 0, 0);">删除</span>
           <span style="color: rgb(178, 0, 255);">同步</span>
         </div>
         <div class="dashboard-el-tree">
           <el-tree :data="data" node-key="id" default-expand-all :props="defaultProps"  @node-click="handleNodeClick">
            <span class="custom-tree-node" slot-scope="{ node, data }">
                <span>
                    <i :class="data.className"></i>{{ node.label }}
                </span>
            </span>
           </el-tree>
         </div>
       </div>
       <!--人员-->
       <div class="dashboard-right">
         <div class="dashboard-right-head">
           <el-button type="danger" icon="el-icon-delete">删除成员</el-button>
           <el-button type="primary" icon="el-icon-plus">新增成员</el-button>
         </div>
         <div>
           <el-table
             ref="multipleTable"
             :data="tableData3"
             tooltip-effect="dark"
             stripe
             style="width: 100%"
             max-height="400"
             @selection-change="handleSelectionChange">
             <el-table-column
               type="selection"
               fixed
               header-align="center"
               width="55">
             </el-table-column>
             <el-table-column
               prop="name"
               label="姓名"
               header-align="center"
               width="120">
             </el-table-column>
             <el-table-column
               prop="account"
               header-align="center"
               label="账号"
               width="300">
             </el-table-column>
             <el-table-column
               prop="phoneNumber"
               header-align="center"
               label="手机"
               width="150">
             </el-table-column>
             <el-table-column
               label="操作"
               header-align="center"
               show-overflow-tooltip>
               <template slot-scope="scope">
                 <el-button type="primary" size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
               </template>
             </el-table-column>
           </el-table>
         </div>
       </div>
     </div>
    <!--部门编辑弹框-->
    <el-dialog
      title="编辑成员"
      :visible.sync="memberDialogVisible"
      width="45%"
      center>
      <div class="memberDialog-formBox">
        <el-form :model="formInlineMember" ref="formInlineMember" label-width="55px" class="demo-ruleForm">
          <div class="member-form">
            <el-form-item label="姓名">
              <el-input v-model="formInlineMember.userName" placeholder="姓名"></el-input>
            </el-form-item>
          </div>
          <div class="member-form">
            <el-form-item label="账号">
              <el-input v-model="formInlineMember.accountNumber" placeholder="账号"></el-input>
            </el-form-item>
          </div>
          <div class="member-form">
            <el-form-item label="性别">
              <el-select v-model="formInlineMember.gender" placeholder="性别" style="width: 100%">
                <el-option label="男" value="男"></el-option>
                <el-option label="女" value="女"></el-option>
              </el-select>
            </el-form-item>
          </div>
          <div class="member-form">
            <el-form-item label="部门">
              <el-input style="width: 75%" v-model="formInlineMember.dept" placeholder="部门"></el-input>
              <el-button type="primary" icon="el-icon-plus">选择部门</el-button>
            </el-form-item>
          </div>
          <div class="member-form">
            <el-form-item label="手机号">
              <el-input v-model="formInlineMember.phoneNumber" placeholder="手机号"></el-input>
            </el-form-item>
          </div>
          <div class="member-form" style="text-align: right">
            <el-form-item>
              <el-button @click="memberDialogVisible = false">取 消</el-button>
              <el-button type="primary" @click="onSubmitSure">确 定</el-button>
            </el-form-item>
          </div>
        </el-form>
      </div>
      <!--<span slot="footer" class="dialog-footer">-->
        <!--<el-button @click="centerDialogVisible = false">取 消</el-button>-->
        <!--<el-button type="primary" @click="centerDialogVisible = false">确 定</el-button>-->
      <!--</span>-->
    </el-dialog>
  </div>

</template>

<script>
export default {
  name: 'dashboard',
  data () {
    return {
      data: [
        {
        id: 1,
        label: '一级 1',
        className: "group-class tree-icon",
        children: [{
          id: 4,
          label: '二级 1-1',
          className: "group-class tree-icon",
          children: [{
            id: 9,
            label: '三级 1-1-1',
            className: "group-class tree-icon",
          }, {
            id: 10,
            className:'group-class tree-icon',
            label: '三级 1-1-2'
          }]
        }]
      }, {
        id: 2,
        label: '一级 2',
        className: "group-class tree-icon",
        children: [{
          id: 5,
          className: "group-class tree-icon",
          label: '二级 2-1',
        }, {
          id: 6,
          className: "group-class tree-icon",
          label: '二级 2-2'
        }]
      }, {
        id: 3,
        className: "group-class tree-icon",
        label: '一级 3',
        children: [{
          id: 7,
          className: "group-class tree-icon",
          label: '二级 3-1'
        }, {
          id: 8,
          className: "group-class tree-icon",
          label: '二级 3-2'
        }]
      }],
      defaultProps: {
        children: 'children',
        label: 'label'
      },
      formInline: {
        content: '',
      },
      formInlineMember:{  //编辑成员
        userName:"",//用户名
        accountNumber:"",//账号
        gender:"", //性别
        phoneNumber:"",//手机号
      },
      multipleSelection: [],
      tableData3: [
        {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }, {
        name: '王小虎',
        account:"0fe9b7f7e9f2ba6ae0a348d90322918a",
        phoneNumber: '13890999293'
      }
      ],
      memberDialogVisible:false
    }
  },
  methods:{
    handleNodeClick(data) {
      console.log(data);
    },
    //搜索人员
    onSubmit() {
      console.log('submit!');
    },
    handleSelectionChange(val) {
      console.log(val);
      this.multipleSelection = val;
    },
    //编辑成员表单
    handleEdit(index, row) {
      var that=this;
      that.memberDialogVisible=true;
      console.log(index, row);
    },
    onSubmitSure:function(){
      var that=this;
      that.memberDialogVisible=false;
    },
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
  .dashboard{
    >.dashboard-head{
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 10px;
      margin-bottom: 10px;
        > .dashboard-title{
          font-size: 20px;
        }
      >.dashboard-search{
        >.dashboard-form{
          display: flex;
          align-items: center;
        }
      }
    }
    >.dashboard-box{
      display: flex;
      justify-content: space-between;
      >.dashboard-left{
        width: 270px;
        height: 100%;
        flex-shrink: 0;
        margin-right: 30px;
        >.dashboard-left-title{
          height: 42px;
          line-height: 42px;
          background-color: #F9F9F9;
          border-bottom: 1px solid #dddddd;
          padding-left: 20px;
          box-sizing: border-box;
          span{
            font-size: 12px;
            margin-left: 2px;
          }
        }
        >.dashboard-el-tree{
          width: 100%;
          background-color: #fff;
          padding-left: 20px;
          box-sizing: border-box;
        }
      }
      >.dashboard-right{
        width:calc(100% - 300px);
        width:-webkit-calc(100% - 300px);
        width:-moz-calc(100% - 300px);
        >.dashboard-right-head{
            width: 100%;
            text-align: left;
            margin-bottom: 10px;
          >button{
            width: 85px;
            height: 32px;
            padding: 0;
          }
        }
      }
    }
  }
  .tree-icon {
    display:inline-block;
  }
  .custom-tree-node{

  }
  //图标设置
  .child-class{
    background:url("../../../assets/img/dep.png");
    width: 16px;
    height: 16px;
    margin-right: 6px;
  }
  //图标设置
  .group-class {
    background:url("../../../assets/img/dep.png");
    width: 16px;
    height: 16px;
    margin-right: 6px;
  }
  .memberDialog-formBox{
    width: 100%;
    >.member-form{
      /*width: 100%;*/
    }
  }

</style>
