<template>
  <div class="dashboard">
    我是首页
    <common-component></common-component>
    <uploadImg></uploadImg>
  </div>
</template>

<script>
export default {
  name: 'dashboard',
  data () {
    return {
    }
  },
  methods:{
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
