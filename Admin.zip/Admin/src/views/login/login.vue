<template>
  <div class="login">
      <div class="content">
          <h3>后台管理系统</h3>
          <div>
            <p><span>用户名&nbsp;:</span><input v-model="userName" type="text" placeholder="请输入用户名"/></p>
            <p><span>密&nbsp;&nbsp;&nbsp;&nbsp;码&nbsp;:</span><input type="password" v-model="password" placeholder="请输入密码"/></p>
            <p><span>验证码&nbsp;:</span><input @keyup.enter="submit" style="width:107px" v-model="verificationCode" type="text" placeholder="请输入验证码"/><span class="verificationCode" @click="refreshCode"><sidentify :identifyCode="identifyCode"></sidentify></span></p>
          </div>
          <el-button v-if="isLogin" class="submit" type="primary" :loading="isLogin">登陆中</el-button>
          <el-button v-else class="submit" type="primary" @click="submit" :loading="isLogin">登陆</el-button>
      </div>
  </div>
</template>

<script>
import bus from '@/assets/js/bus'
import { login } from '@/api/loginApi'
import sidentify from './identify'
export default {
  name: 'login',
  data () {
    return {
     userName:"",
     password:"",
     isLogin:false,  //点击登陆时 变为true 表示在登陆中
     verificationCode: "", // 用户填的验证码
     identifyCode: "" // 我们生成的验证码
    }
  },
  components: { sidentify },
  created() {
    this.makeCode(4)
  },
  methods:{
    submit(){
      var _this=this;
      this.isLogin=true;
      console.log("验证码："+this.identifyCode);
      // 不调接口登录
      if(_this.userName==''){
        _this.$message({
          showClose: true,
          message: '请输入用户名',
          type: 'warning'
        });
        _this.isLogin=false;
        return false;
      }

      if(this.password!='123456'){
        this.$message({
          showClose: true,
          message: '密码输入错误，请重试',
          type: 'warning'
        });
        _this.isLogin=false;
        return false;
      }
      if(_this.verificationCode!=_this.identifyCode){
          this.$message({
          showClose: true,
          message: '验证码输入错误',
          type: 'warning'
        });
        _this.isLogin=false;
        _this.verificationCode="";
        _this.refreshCode();
        return false;
      }

      // 调接口登录
      const data = {
        "loginname": _this.userName,
        "loginpwd": _this.password
      };
      login(data).then(res => {
        console.log(res.data);
        if(res.data.returncode==0){
          var data=JSON.parse(res.data.data);
          console.log(data);
          localStorage.setItem("admin",data.token);
            _this.$router.push({
              path:"/"
            })
        }else{
          _this.$message({
            showClose: true,
            message: '账号或密码错误，请重新输入',
            type: 'warning'
          });
          _this.isLogin=false;
        }


      }).catch(error => {
        _this.isLogin=false;
        console.log(error);

        var str = error + '';
        if(str.search('timeout')!== -1){  //请求超时
            _this.$message({
              showClose: true,
              message: '登陆超时，请重新登陆',
              type: 'warning'
            });
        }else{
            _this.$message({
              showClose: true,
              message: '登陆错误，请重新登陆或联系管理员',
              type: 'warning'
            });
        }

      })

    },
    // 生成验证码
    randomNum() {
      const Num = Math.floor(Math.random()*10)
      return Num
    },
    refreshCode() {
      this.identifyCode = ""
      this.makeCode(4)
      console.log("当前验证码==="+this.identifyCode)
    },
    makeCode(length) {
      for (let i = 0; i < length; i++) {
        this.identifyCode += this.randomNum()
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.login{
  background-image: url("../../assets/img/login-bg.jpg");
  width: 100%;
  height: 100%;
  position: relative;
  background-size: 100%;
}
.content{
  width:350px;
  height:300px;
  background-color: rgba(255,255,255,0.3);
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%,-50%);
  border-radius: 7px;
}
.content h3{
  color:#409eff;
  margin: 0;
  height:58px;
  line-height: 58px;
  text-align: center;
  border-bottom: 1px solid #ddd;
}
.content>div{
  margin-top: 22px;
  width: 350px;
  padding: 0 20px;
  box-sizing: border-box;
}
.content>div>p{
  height: 30px;
}
.content>div>p span{
  display: inline-block;
  width: 70px;
  margin-right: 8px;
  color:#333;
  font-weight: 600;
}
.content>div>p span.verificationCode{
  display: inline-block;
  width: 107px;
  height: 100%;
  background-color: gray;
  position: relative;
  margin-right: 0;
  top: 13px;
  left: 10px;
}
.content>div>p input{
  width: 225px;
  height:30px;
  outline: none;
  border: none;
  padding-left: 5px;
border-radius: 3px;
}
.submit{
  width: 310px;
  height: 35px;
  background-color: #409EFF;
  color: #fff;
  text-align: center;
  line-height: 35px;
  font-size: 16px;
  margin-left: 20px;
  margin-top: 30px;
  cursor: pointer;
  border-radius: 3px;
  padding: 0;
}
</style>
