<template>
  <div class="dashboard">
    我是通知公告
  </div>
</template>

<script>
export default {
  name: 'dashboard',
  data () {
    return {
    }
  },
  methods:{
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
