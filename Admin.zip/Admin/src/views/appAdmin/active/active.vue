<template>
  <div class="dashboard">
    我是活动列表
  </div>
</template>

<script>
export default {
  name: 'dashboard',
  data () {
    return {
    }
  },
  methods:{
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
