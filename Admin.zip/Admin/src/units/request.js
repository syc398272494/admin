// 封装请求
// 引入vue
import axios from 'axios'
import qs from 'qs'

// 创建axios实例
const service = axios.create({
  baseURL: 'http://qy.sunjee.cn:6002', // 接口地址公共部分
  timeout: 5000, // 请求超时时间
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded',
    'Accept': 'application/json'
  }
})

// 请求拦截
service.interceptors.request.use(req =>{
  // 可以在请求发出之前拦截请求参数，可以往参数中添加固定的参数  如秘钥、用户名、密码等
  //console.log(req)
  // 设置请求参数拼接规范
  if (req.method === 'post') {
    // 设置参数拼接方式
      if (req.data && req.headers['Content-Type'] === 'application/x-www-form-urlencoded') {
        req.data = qs.stringify(req.data)
      }
    } else {
      if (req.data) {
        req.url = config.url + '?' + qs.stringify(req.data)
      }
    }
  return req
})

// 返回拦截
service.interceptors.response.use(res => {
  // 在返回数据到达页面之前拦截
  //console.log(res)
  return res
})

export default service
