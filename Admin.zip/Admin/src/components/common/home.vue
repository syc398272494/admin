<template>
  <div class="home">
    <!-- 头部 -->
    <hed></hed>
    <!-- 左侧菜单 -->
    <sideBar></sideBar>
    <div class="content-box">
      <tabs></tabs>
      <div class="content">
        <transition name="move" mode="out-in">
          <router-view></router-view>
        </transition>
      </div>
    </div>
  </div>
</template>

<script>
  import hed from './hed'
  import sideBar from './sideBar/index'
  import tabs from './tabs'
export default {
  name: 'home',
  components:{
    hed,sideBar,tabs
  },
  data () {
    return {
    }
  },
  methods:{
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less" scoped>
.sidebar-wrapper{
  position: absolute;
  width: 250px;
  top:70px;
  bottom: 0;
  background-color: #545c64;
}
.content-box {
    position: absolute;
    left: 250px;
    right: 0;
    top: 70px;
    bottom: 0;
    padding-bottom: 30px;
    -webkit-transition: left .3s ease-in-out;
    transition: left .3s ease-in-out;
    background: #f0f0f0;
  overflow-y: auto;
}
.content{
  margin:10px 5px 5px 5px;
}
</style>
