<template>
  <div class="tabs" v-show="tabs.length!=0">
  	<div class="tabLeft">
  		  <span @click.stop="tabTz(item.url)" v-for="(item,index) in tabs" :class="{'blue':item.url==urls}">
          {{item.name}} <i class="el-icon-close" @click.stop="close(item.url,index)"></i></span>
  	</div>
    <div class="tabRight">

    </div>
  </div>
</template>

<script>
import bus from '@/assets/js/bus'
export default {
  name: 'tabs',
  data () {
    return {
      tabs:[
      ],
      urls:""  //获取当前路由 判断tab标签与 当前路由是否一样 则状态改变
    }
  },
  mounted:function(){
    var _this=this;
    bus.$on('tags',(msg)=>{
      console.log(_this.$route.path);
      _this.urls=msg.url;
      let num=0;
      for(var i=0;i<_this.tabs.length;i++){
        if(_this.tabs[i].name!=msg.name){
          num++;
        }
      }
      console.log(num);
      if(num==_this.tabs.length){
        _this.tabs.push(msg);
      }
      
    })
  },
  methods:{
    tabTz:function(url){  //跳转
      this.urls=url;
      this.$router.push({
        path:"/"+url
      })
      bus.$emit('path',url);
    },
    close:function(url,index){  //关闭tab
      var _this=this;
      if(_this.urls==url){  //如果关掉得是 当前页 会跳转到当前页得前一个标签 若没有前一个就跳到后一个标签 若都没有 都就关闭 跳转到首页
        console.log(index-1);
        if((index-1)>=0){
          _this.urls=_this.tabs[index-1].url;
          _this.tabs.splice(index,1);
          _this.$router.push({
            path:"/"+_this.tabs[index-1].url
          })
          bus.$emit('path',_this.tabs[index-1].url);
        }else{
          _this.tabs.splice(index,1);
          if(_this.tabs.length!=0){
            _this.urls=_this.tabs[0].url;
            _this.$router.push({
              path:"/"+_this.tabs[0].url
            })
            bus.$emit('path',_this.tabs[0].url);
          }else{
            _this.$router.push({
              path:'/dashboard'
            })
            bus.$emit('path','dashboard');
          }
        }
      }else{   //关闭得不是当前页   直接关闭
        _this.tabs.splice(index,1);
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.tabs{
  margin: 0;
  padding: 0;
  width: 100%;
  height: 33px;
  background-color: #fff;
  
}
.tabLeft span{
  text-decoration: none;
  display: inline-block;
  height: 25px;
  padding: 0 7px 0 15px;
  background-color: #fff;
  color: #666;
  text-align: center;
  line-height: 25px;
  margin-top: 3px;
  margin-left: 4px;
  border-radius: 5px;
  border: 1px solid #e9eaec;
  font-size: 12px;
  cursor: pointer;
}
.tabLeft span:hover{
  background-color: rgb(250,250,250);
}
.tabLeft span>i{
  font-size: 12px;
  font-style: normal;
  padding-left: 7px;
}
.tabLeft span.blue{
  background-color: #409eff;
  border:1px solid #409eff;
  color: #fff;
}
</style>
