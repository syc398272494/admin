<template>
  <div class="header">
    <div class="title">
      <i class="el-icon-news"></i>
      <h3>后台管理系统</h3>
    </div>
    <div class="right">
      <div class="header-right">
        <div class="header-user-con">
          <!-- 用户头像 -->
          <div class="user-avator"><img src="../../assets/img/img.jpg"></div>
          <!-- 用户名下拉菜单 -->
          <el-dropdown class="user-name" trigger="click" @command="handleCommand">
                    <span class="el-dropdown-link">
                        {{admin}} <i style="color:#000000" class="el-icon-caret-bottom"></i>
                    </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item @click.stop="tab"> 修改密码</el-dropdown-item>
              <el-dropdown-item divided  command="loginout" @click.stop="tab">退出登录</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import bus from '@/assets/js/bus'

  export default {
    name: 'hed',
    data() {
      return {
        show: false,
        admin: "",
      }
    },
    created: function () {
      this.admin = sessionStorage.getItem("admin");
    },
    methods: {
      tab() {
        sessionStorage.removeItem("admin");
        this.$router.push({
          path: "/login"
        })
      },
      // 用户名下拉菜单选择事件
      handleCommand(command) {
        if(command == 'loginout'){
          localStorage.removeItem('ms_username')
          this.$router.push('/login');
        }
      },
    },
    mounted() {
      var _this = this;
      bus.$on('seta', msg => {
        _this.admin = msg;
      })
    }
  }
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .header {
    position: relative;
    width: 100%;
    height: 69px;
    background-color: #fff;
    color: #666;
    font-size: 17px;
    border-bottom: 1px solid #efefef;
  }
  .title {
    width: 50%;
    height: 70px;
    float: left;
    color: #666;
    line-height: 70px;
    padding-left: 30px;
  }
  .title h3 {
    display: inline-block;
    margin: 0;
  }
  .header-right{
    float: right;
    padding-right: 50px;
  }
  .header-user-con{
    display: flex;
    height: 70px;
    align-items: center;
  }
  .btn-fullscreen{
    transform: rotate(45deg);
    margin-right: 5px;
    font-size: 24px;
  }
  .btn-bell, .btn-fullscreen{
    position: relative;
    width: 30px;
    height: 30px;
    text-align: center;
    border-radius: 15px;
    cursor: pointer;
  }
  .btn-bell-badge{
    position: absolute;
    right: 0;
    top: -2px;
    width: 8px;
    height: 8px;
    border-radius: 4px;
    background: #f56c6c;
    color: #fff;
  }
  .btn-bell .el-icon-bell{
    color: #fff;
  }
  .user-name{
    margin-left: 10px;
  }
  .user-avator{
    margin-left: 20px;
  }
  .user-avator img{
    display: block;
    width:40px;
    height:40px;
    border-radius: 50%;
  }
  .el-dropdown-link{
    cursor: pointer;
  }
  .el-dropdown-menu__item{
    text-align: center;
  }
</style>
