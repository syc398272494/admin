<template>
  <div class="sidebar-wrapper">
    <el-menu
      :default-active="active"
      :unique-opened="isShow" 
      class="el-menu-vertical-demo"
      @select="menuSelected"
      background-color="#545c64"
      text-color="#fff"
      active-text-color="#409eff">
        <nav-menu :navMenus="leftMenus"></nav-menu>
    </el-menu>
  </div>
</template>

<script>
import axios from 'axios'
import NavMenu from './NavMenu'
import bus from '@/assets/js/bus'
export default {
  data() {
    return {
      leftMenus: [], // 菜单栏的数据
      active: 'dashboard', // 选中的菜单
      isShow:true
    }
  },
  components: { NavMenu },
  created() {
    this.active=this.$route.name;
    this.getMenuData()
  },
  mounted(){
    var _this=this;
    bus.$on('path',(path)=>{  //点击tabs标签页 传值  左侧路由跟着跳
      _this.active=path;
    })
  },
  methods: {
    getMenuData() {  
      axios.get('http://localhost:8080/static/sideBarData.json').then(res => {
        this.leftMenus = res.data.list
      })
    },
    menuSelected(index,indexPath){
      const path = indexPath[indexPath.length -1]
      this.active = path
      this.$router.options.routes.forEach(item => {
        if (item.children) {
          for (let i = 0; i < item.children.length; i++){
            if (item.children[i].name === path) {
              this.pathName = item.children[i].meta.title // 当前点击的菜单路由的名字
              // console.log(item.children[i].meta.title)
              // console.log(item.children[i].path) // 当前点击的菜单路由的path路径
              var tags={
                url:item.children[i].name,
                name:item.children[i].meta.title
              }
              bus.$emit('tags',tags);
              return
            }
          }
        }
      });
      this.$router.push({name: path})
    }
  }
}
</script>

<style lang="less" scoped>
.sidebar-wrapper{
  .el-menu{
    border-right: none;
  }
}
</style>
