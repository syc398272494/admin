<template>
  <div class="navMenu">
 
    <label v-for="navMenu in navMenus" :key="navMenu.id">
    	<!--只有一级菜单-->
      <el-menu-item v-if="navMenu.childs==null&&navMenu.entity&&navMenu.entity.state==='ENABLE'"
        @select="select"
        :key="navMenu.entity.id" :data="navMenu" :index="navMenu.entity.name" :route="navMenu.entity.value">
        <!--标题-->
        <span slot="title">{{navMenu.entity.alias}}</span>
      </el-menu-item>
      <!--有多级菜单-->
      <el-submenu v-if="navMenu.childs&&navMenu.entity&&navMenu.entity.state==='ENABLE'"
        :key="navMenu.entity.id" :data="navMenu" :index="navMenu.entity.name">
        <template slot="title">
          <span> {{navMenu.entity.alias}}</span>
        </template>
        <!--递归组件，把遍历的值传回子组件，完成递归调用-->
        <nav-menu :navMenus="navMenu.childs"></nav-menu>
      </el-submenu>
    </label>
 
  </div>
</template>
 
<script>
  export default {
    name: 'NavMenu', //使用递归组件必须要有名字
    props: ['navMenus'], // 传入子组件的数据
    data() {
      return {}
    },
    methods: {
      select(index, indexPath) {
        console.log(index)
        console.log(indexPath)
      }
    }
  }
</script>

<style lang="less" scoped>
.sidebar-item-wrapper{

}
</style>
