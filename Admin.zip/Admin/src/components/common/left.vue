<template>
  <div class="left">
    
    <el-menu class="sidebar-el-menu" :default-active="onRoutes" background-color="#324157"
            text-color="#bfcbd9" active-text-color="#20a0ff" unique-opened router>
            <template v-for="item in items">
                <template v-if="item.subs">
                    <el-submenu :index="item.index" :key="item.index">
                        <template slot="title">
                            <i :class="item.icon"></i><span slot="title">{{ item.title }}</span>
                        </template>
                        <template v-for="subItem in item.subs">
                            <el-submenu v-if="subItem.subs" :index="subItem.index" :key="subItem.index">
                                <template slot="title">{{ subItem.title }}</template>
                                <template v-for="it in subItem.subs">
                                    <el-submenu v-if="it.subs" :index="it.index" :key="it.index">
                                        <template slot="title">{{ it.title }}</template>
                                        <el-menu-item v-for="(fourItem,i) in it.subs" :key="i" :index="fourItem.index">
                                            {{ fourItem.title }}
                                        </el-menu-item>
                                    </el-submenu>
                                    <el-menu-item v-else :index="it.index" :key="it.index">
                                        {{ it.title }}
                                    </el-menu-item>
                                </template>
                            </el-submenu>
                            <el-menu-item v-else :index="subItem.index" :key="subItem.index">
                                {{ subItem.title }}
                            </el-menu-item>
                        </template>
                    </el-submenu>
                </template>
                <template v-else>
                    <el-menu-item :index="item.index" :key="item.index">
                        <i :class="item.icon"></i><span slot="title">{{ item.title }}</span>
                    </el-menu-item>
                </template>
            </template>
        </el-menu>
  </div>
</template>

<script>
import bus from '@/assets/js/bus';
import {mapActions, mapGetters} from 'vuex'
export default {
  name: 'left',
  data () {
    return {
        show:true,
        // data: [{
        //   label: '首页',
        //   index:'/dashboard',
        // }, {
        //   label: '系统设置',
        //   children: [{
        //     label: '菜单管理',
        //     index:'/setup'
        //   }, {
        //     label: '组织架构',
        //     index:'/organi'
        //   },{
        //     label: '角色管理',
        //     index:'/role'
        //   },
        //   {
        //     label: '用户管理',
        //     index:'/userMent'
        //   },{
        //     label: '测试',
        //     children: [{
        //       label: '角色管理',
        //       index:'/role'
        //     }]
        //   }

        //   ]
        // }, {
        //   label: '应用管理',
        //   children: [{
        //     label: '通知公告',
        //     index:'/notice'
        //   }, {
        //     label: '活动列表',
        //     index:'/active'
        //   }]
        // }],
                items: [
                    {
                        icon: 'el-icon-news',
                        index: 'dashboard',
                        title: '首页'
                    },
                    {
                        icon: 'el-icon-document',
                        index: '2',
                        title: '系统设置',
                        subs:[
	                        {
	                        	index:"setup",
	                        	title:"菜单管理"
	                        },
                            {
                                index:"userMent",
                                title:"用户管理"
                            },
                            {
                                index:"organi",
                                title:"组织架构"
                            },
                            {
                                index:"role",
                                title:"角色管理"
                            },
                            {
                                index:"2-1",
                                title:"测试",
                                subs:[
                                    {
                                        index:"role",
                                        title:"角色管理"
                                    }
                                ]
                            },

                        ]
                    },
                    {
                        icon: 'el-icon-document',
                        index:"3-1",
                        title:"应用管理",
                        subs:[
                            {
                                index:'notice',
                                title:"通知公告"
                            },
                            {
                                index:'active',
                                title:"活动列表"
                            },
                        ]
                    }
                ]
            }
  },

        computed: {
            onRoutes(){
                return this.$route.path.replace('/','');
            },
      ...mapGetters(['leftList']) // 动态计算属性，相当于this.$store.getters.leftList
  },
    mounted(){
        var _this=this;
           bus.$on('setItems',msg=>{
            _this.items=msg;
           })

           this.$nextTick(function(){
                $(".left .el-tree-node__content").each(function(){
                    console.log("1");
                    $(this).height("45px");
                    $(this).siblings().find(".el-tree-node__content").each(function(){
                        $(this).height("45px");
                        console.log("2");
                    })
                })
           })
    },
  methods:{
    handleNodeClick(data) {
        if(!data.children){
            this.$router.push({
                path:data.index
            })
        }
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.left{
	 display: block;
        position: absolute;
        left: 0;
        top: 70px;
        bottom:0;
        overflow-y: auto;
        width: 250px;
        background-color: rgb(50, 65, 87);
}
.left>div{
     background-color: rgb(50, 65, 87);
}
.left .el-tree-node.is-current>.el-tree-node__content span.el-tree-node__label{
    color: rgb(191, 203, 217) !important;
}
.left>div span.el-tree{
    color: rgb(191, 203, 217) !important;
}
.left .el-tree--highlight-current .el-tree-node.is-current>.el-tree-node__content{
    background-color: rgb(50, 65, 87) !important;
}
.left > ul {
        height:100%;
    }
</style>
