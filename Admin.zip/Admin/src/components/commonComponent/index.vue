<template>
  <div class="header-wrapper">
    我是公共组件
  </div>
</template>

<script>
export default {
  
}
</script>

<style>

</style>

