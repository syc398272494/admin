// 引入组件
import commonComponent from '@/components/commonComponent/index'
import chooseDu from '@/components/chooseUD/index'
import uploadImg from '@/components/imgUpload/imgUpload'

const components = {
  commonComponent,chooseDu,uploadImg
}

// 统一注册
const install = function(Vue, opts = {}) {
  Object.keys(components).forEach(key => {
    console.log(key)
    Vue.component(key, components[key])
  })
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

export default {
  components,
  install
}
