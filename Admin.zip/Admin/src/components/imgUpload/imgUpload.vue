<template>
  <div class="imgup">
    <button class="btn" @click="toggleShow">set avatar</button>
    <my-upload field="img"
               @src-file-set="myOption"
               @crop-success="cropSuccess"
               @crop-upload-success="cropUploadSuccess"
               @crop-upload-fail="cropUploadFail"
               v-model="show"
               :height="300"
               :width="300"
               :url="uploadUrl"
               :params="params"
               :headers="headers"
               img-format="png"></my-upload>
    <img :src="imgDataUrl">
  </div>
</template>

<script>
  import myUpload from 'vue-image-crop-upload'

  export default {
    name: "imgup",
    data() {
      return {
        uploadUrl: 'localhost:8888',
        show: false,
        params: {
          token: '123456798',
          name: 'avatar'
        },
        headers: {
          smail: '*_~'
        },
        imgDataUrl: '' // the datebase64 url of created image
      }
    },
    components: {
      myUpload
    },
    methods: {
      //图片选择后
      myOption() {
        alert(1)
      },
      toggleShow() {
        this.show = !this.show;
      },
      /**
       * crop success
       *  保存图片
       * [param] imgDataUrl
       * [param] field
       */
      cropSuccess(imgDataUrl, field) {
        console.log('-------- crop success --------');
        console.log(imgDataUrl);
        this.imgDataUrl = imgDataUrl;
      },
      /**
       * upload success
       *
       * [param] jsonData  server api return data, already json encode
       * [param] field
       */
      cropUploadSuccess(jsonData, field) {
        // debugger
        console.log('-------- upload success --------');
        console.log(jsonData);
        console.log('field: ' + field);
      },
      /**
       * upload fail
       *
       * [param] status    server api return error status, like 500
       * [param] field
       */
      cropUploadFail(status, field) {
        // debugger
        console.log('-------- upload fail --------');
        console.log(status);
        console.log('field: ' + field);
      }
    }
  }
</script>

<style scoped>

</style>
