<!--
    * 选择部门组件
    * allDate 父组件传值给 选部门子组件
    * activeName      2 多选人      4 单选人        单选 和多选不能一起使用
    * url   请求地址
    * depts 选中的部门列表
    * users 选中的人员列表
    * selDeptId 选择人员时 当前人员所属部门的id  
    * deptList 部门的数据源 数组
    * userList 人员的数据源 数组    可通过 selDeptId  来获取人员数据
    * vuexSet  vuex里定义的 设置 数据的方法名
-->
<template>
    <div v-if="allDate.selDeptId!=''" class="chooseUser" :class="{'user':allDate.activeName==2||allDate.activeName==4}">
        <div>
            <p v-for="(item,index) in allDate.userList" :key="item.deptId" @click="choose(item.deptId,index,item)" :class="{'gary':item.show}">
                <img class="headPortrait" :src="item.img" alt="">
                <span>{{item.name}}</span> 
                <img class="choose" v-if="item.show" src="../../../assets/img/selection.png" alt=""> 
                <img class="choose" v-else-if="!item.show" src="../../../assets/img/unchecked.png" alt=""> 
            </p>
            <p v-show="show">无人员</p>
        </div>
    </div>
</template>

<script>
import {mapGetters} from 'vuex'
import stateAllDtat from '@/store/store'
import { getUsers } from '@/api/getDeptUser'   //获取部门、人员等数据
    export default {
        name: "chooseUser",
        props:['depId'],
        data(){
            return{
                show:false,
                list:[
                    
                ]

            }
        },
        computed:mapGetters({
            allDate:'GET_MSG'  //获取vuex 里面存储的值
        }),
        mounted(){
        },
        methods:{
            choose(id,index,items){
                var _this=this;
                if(_this.list.activeName==2){
                    _this.list.userList[index].show=!_this.list.userList[index].show;
                    if(_this.list.userList[index].show==true){   //若值为true 则将数组添加到 list.users数组里面
                        _this.list.users.push(_this.list.userList[index]);
                    }else{       //若值为false 则将数组 list.users里删除当前数据
                        this.list.users.map((item,index)=>{
                            if (item.name === items.name) {
                                this.list.users.splice(index, 1);
                            }
                        })
                    }
                    this.$store.commit(this.list.vuexSet,this.list);  //将改变的值 更新到vuex

                }else if(_this.list.activeName==4){    //单选人员
                    _this.list.userList[index].show=!_this.list.userList[index].show;
                    
                    if(_this.list.userList[index].show==true){   //若值为true 则将数组添加到 list.users数组里面
                        this.list.userList.map((item,indexs)=>{
                            if (index != indexs) {
                                this.list.userList[indexs].show=false;
                            }
                        })
                        _this.list.users=[];
                        _this.list.users.push(_this.list.userList[index])
                    }else{       //若值为false 则将数组 list.users里删除当前数据
                        this.list.users.map((item,index)=>{
                            if (item.name === items.name) {
                                this.list.users.splice(index, 1);
                            }
                        })
                    }
                    this.$store.commit(this.list.vuexSet,this.list);  //将改变的值 更新到vuex
                }
            },
            getUser(id){   //获取人员 并更新给vuex
            this.list=this.$store.state.allDept;
                if(id==2){
                    this.list.userList=[
                    {deptId:10,name:'刘备',show:false,img:require('../../../assets/img/img.jpg')},
                    {deptId:11,name:'关羽',show:false,img:require('../../../assets/img/img.jpg')},
                    {deptId:12,name:'张飞',show:false,img:require('../../../assets/img/img.jpg')},
                    {deptId:13,name:'曹丕',show:false,img:require('../../../assets/img/img.jpg')},
                    {deptId:14,name:'诸葛亮',show:false,img:require('../../../assets/img/img.jpg')},
                    {deptId:15,name:'周瑜',show:false,img:require('../../../assets/img/img.jpg')},
                    {deptId:16,name:'黄盖',show:false,img:require('../../../assets/img/img.jpg')},
                    {deptId:17,name:'黄忠',show:false,img:require('../../../assets/img/img.jpg')},
                    ];
                    for(let i=0;i<this.list.userList.length;i++){
                        for(let j=0;j<this.list.users.length;j++){
                            if(this.list.users[j].name==this.list.userList[i].name){
                                this.list.userList[i].show=true;
                            }
                        }
                    }

                    this.show=false;
                }else if(id==3){
                    this.list.userList=[
                    {deptId:16,name:'黄盖',show:false,img:require('../../../assets/img/img.jpg')},
                    {deptId:17,name:'黄忠',show:false,img:require('../../../assets/img/img.jpg')},
                ];
                this.show=false;
                }else{
                    this.list.userList=[];
                    this.show=true;
                }
                

                
                this.$store.commit(this.list.vuexSet,this.list);
                getUsers('','').then((res)=>{
                    //console.log(res)
                }).catch((error)=>{
                    //console.log(error);
                })
            },
        },
        watch:{
            depId(id){
                this.getUser(this.depId);

            }
        }
    }
</script>

<style lang="less" scoped>
    .chooseUser{
        float: left;
        width: 49%;
        font-size: 14px;
        color: #666;
       >div{
            max-height: 350px;
            overflow-y: scroll;
            border: 1px solid #ccc;
            background-color: #fff;
            
            >p{
                padding: 0 15px;
                box-sizing: border-box;
                margin: 0;
                cursor: pointer;
                height: 45px;
                line-height: 45px;
                border-bottom: 1px solid #ccc;
                .headPortrait{
                    width:30px;
                    vertical-align: middle;
                    margin-right: 10px;
                }
                .choose{
                    width: 17px;
                    margin-top: 14px;
                    float: right;
                }
            }
            >p.gary{
               background-color:#ddd; 
            }
            >p:hover{
                background-color: #efefef;
            }
       }
    }
    

</style>