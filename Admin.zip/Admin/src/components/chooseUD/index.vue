<!--
    * 选择部门组件
    * sendData 父组件传值给 选部门子组件
    * activeName   1 多选部门   2 多选人   3 单选部门   4 单选人        单选 和多选不能一起使用
    * url   请求地址
    * depts 选中的部门列表
    * users 选中的人员列表
    * selDeptId 选择人员时 当前人员所属部门的id  
    * deptList 部门的数据源 数组
    * userList 人员的数据源 数组    可通过 selDeptId  来获取人员数据
    * vuexSet  vuex里定义的 设置 数据的方法名
-->
<template>
  <div class="choose-dept-user">
    <!--搜索-->
    <el-select v-model="searchInfo"
               filterable
               remote
               placeholder="请选择搜索内容"
               :remote-method="remoteMethod"
               clearable
               @change="handleSelect"
    >
      <el-option-group
        v-for="group in theOption"
        :key="group.label"
        :label="group.label">
        <el-option
          v-for="item in group.options"
          :key="item.value"
          :label="item.label"
          :value="item.value">
        </el-option>
      </el-option-group>
    </el-select>

    <!---->
    <div class="chooseMsg">
          <span v-for="(item,index) in allDate.users" :key="item.deptId" class="user" @click="delUser(item.name,index)">
          {{item.name}} <i class="el-icon-close"></i></span>
      <span v-for="(item,index) in allDate.depts" @click="delDept(item.name,index)" :key="item.deptId" class="dept">
          {{item.name}} <i class="el-icon-close"></i></span>
    </div>
    <el-tabs v-model="allDeptMsg.activeName">
      <el-tab-pane label="部门" name="1">
        <choose-dept :sendData="allDeptMsg"></choose-dept>
      </el-tab-pane>
      <el-tab-pane label="人员" name="2">
        <choose-dept @selDeptId="getUserMsg" :sendData="allDeptMsg"></choose-dept>
        <choose-user :depId="getUsersId"></choose-user>
      </el-tab-pane>
    </el-tabs>
    <div>
      <button @click="hq">获取</button>
    </div>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'
  import chooseUser from './user/chooseUser'
  import chooseDept from './dept/chooseDept'

  export default {
    name: "index",
    components: {
      chooseUser, chooseDept
    },
    data() {
      return {
        theOption: [
          {
            label: '部门',
            options: []
          }, {
            label: '人员',
            options: []
          }
        ],
        loading: true,//加载中...
        searchInfo: '',   //搜索内容
        getUsersId: '',
        allDeptMsg: {   //传递给选部门 或者选人的数据  通过父子组件传值  :sendData="allDeptMsg"
          activeName: "1",  //类型
          url: "",   //请求数据的地址
          depts: [],   //选中的 部门列表
          users: [],  //选中的人员列表
          selDeptId: "",  //选择人员时 当前人员所属部门的id
          deptList: [],   //选择部门数据
          userList: [], //选择人员数组
          vuexGets: 'GET_MSG',   //vuex里定义的 获取 数据的方法名
          vuexSet: 'SET_MSG'    //vuex里定义的 设置 数据的方法名
        }
      }
    },
    computed: mapGetters({
      allDate: 'GET_MSG'  //获取vuex 里面存储的值
    }),
    mounted() {
      this.$store.commit('SET_MSG', this.allDeptMsg);
    },
    methods: {
      //选中
      handleSelect(val) {
        let theFlag = true;
        let theId = '';
        console.log(this.allDeptMsg);
        console.log(val);
        this.allDeptMsg.deptList.map((item, index) => {
          if (item.name === val) {
            item.show = true;
            theFlag = false;
            theId = item.id;
          }
        })
        if(theFlag === false){
          this.allDeptMsg.depts.push({deptId: theId, name: val, show: true, value: val, label: val},);

        }else{
          this.allDeptMsg.users.push(val);
        }
        // console.log(this.searchInfo);
        // this.$store.commit('SET_MSG', this.allDeptMsg);
      },

      //搜索 方法
      remoteMethod() {
        new Promise((resolve,reject) => {
          let userInfo = [{deptId: 10, name: '刘备', show: false, img: require('../../assets/img/img.jpg'), value: '刘备', label: '刘备',},
            {deptId: 11, name: '关羽', show: false, img: require('../../assets/img/img.jpg'), value: '关羽', label: '关羽',},
            {deptId: 12, name: '张飞', show: false, img: require('../../assets/img/img.jpg'), value: '张飞', label: '张飞',},
            {deptId: 13, name: '曹丕', show: false, img: require('../../assets/img/img.jpg'), value: '曹丕', label: '曹丕',},
            {
              deptId: 14,
              name: '诸葛亮',
              show: false,
              img: require('../../assets/img/img.jpg'),
              value: '诸葛亮',
              label: '诸葛亮',
            },
            {deptId: 15, name: '周瑜', show: false, img: require('../../assets/img/img.jpg'), value: '周瑜', label: '周瑜',},
            {deptId: 16, name: '黄盖', show: false, img: require('../../assets/img/img.jpg'), value: '黄盖', label: '黄盖',},
            {deptId: 17, name: '黄忠', show: false, img: require('../../assets/img/img.jpg'), value: '黄忠', label: '黄忠',}]
          let deptInfo = [
            {deptId: 1, name: '研发五部', show: false, value: '研发五部', label: '研发五部',},
            {deptId: 2, name: '研发三部', show: false, value: '研发三部', label: '研发三部'},
            {deptId: 3, name: '测试部', show: false, value: '测试部', label: '测试部'},
            {deptId: 4, name: '销售部', show: false, value: '销售部', label: '销售部'},
            {deptId: 5, name: '产品部', show: false, value: '产品部', label: '产品部'},
            {deptId: 6, name: '总裁班', show: false, value: '总裁班', label: '总裁班'},
            {deptId: 7, name: '研发一部', show: false, value: '研发一部', label: '研发一部'},
            {deptId: 8, name: '研发二部', show: false, value: '研发二部', label: '研发二部'},
            {deptId: 9, name: '研发四部', show: false, value: '研发四部', label: '研发四部'},
            {deptId: 10, name: '财务部', show: false, value: '财务部', label: '财务部'},
          ]
          this.theOption[0].options=deptInfo
          this.theOption[1].options=userInfo
        })
        /*this.theOption = [{//搜索获取的数据
          label: '部门',
          options: [
            {deptId: 1, name: '研发五部', show: false, value: '研发五部', label: '研发五部',},
            {deptId: 2, name: '研发三部', show: false, value: '研发三部', label: '研发三部'},
            {deptId: 3, name: '测试部', show: false, value: '测试部', label: '测试部'},
            {deptId: 4, name: '销售部', show: false, value: '销售部', label: '销售部'},
            {deptId: 5, name: '产品部', show: false, value: '产品部', label: '产品部'},
            {deptId: 6, name: '总裁班', show: false, value: '总裁班', label: '总裁班'},
            {deptId: 7, name: '研发一部', show: false, value: '研发一部', label: '研发一部'},
            {deptId: 8, name: '研发二部', show: false, value: '研发二部', label: '研发二部'},
            {deptId: 9, name: '研发四部', show: false, value: '研发四部', label: '研发四部'},
            {deptId: 10, name: '财务部', show: false, value: '财务部', label: '财务部'},
          ]
        }, {
          label: '人员',
          options: [
            {deptId: 10, name: '刘备', show: false, img: require('../../assets/img/img.jpg'), value: '刘备', label: '刘备',},
            {deptId: 11, name: '关羽', show: false, img: require('../../assets/img/img.jpg'), value: '关羽', label: '关羽',},
            {deptId: 12, name: '张飞', show: false, img: require('../../assets/img/img.jpg'), value: '张飞', label: '张飞',},
            {deptId: 13, name: '曹丕', show: false, img: require('../../assets/img/img.jpg'), value: '曹丕', label: '曹丕',},
            {
              deptId: 14,
              name: '诸葛亮',
              show: false,
              img: require('../../assets/img/img.jpg'),
              value: '诸葛亮',
              label: '诸葛亮',
            },
            {deptId: 15, name: '周瑜', show: false, img: require('../../assets/img/img.jpg'), value: '周瑜', label: '周瑜',},
            {deptId: 16, name: '黄盖', show: false, img: require('../../assets/img/img.jpg'), value: '黄盖', label: '黄盖',},
            {deptId: 17, name: '黄忠', show: false, img: require('../../assets/img/img.jpg'), value: '黄忠', label: '黄忠',},
          ]
        }]*/
      },
      getUserMsg(id) {  //选择人员时  部门选择后传id给 选人组件  通过父子组件传值 :depId="getUsersId"
        this.getUsersId = id;
      },
      //点击删除部门  item 为当前allDeptMsg.depts删除的对象  theIndex为当前索引
      delDept(name, theIndex) {
        this.allDeptMsg.depts.splice(theIndex, 1);
        for (let i = 0; i < this.allDeptMsg.deptList.length; i++) {
          if (this.allDeptMsg.deptList[i].name == name) {
            this.allDeptMsg.deptList[i].show = false;
          }
        }
        this.$store.commit('SET_MSG', this.allDeptMsg);
      },
      //点击删除人员  item 为当前allDeptMsg.users删除的对象  theIndex为当前索引
      delUser(name, theIndex) { //点击删除选人  item 为当前allDeptMsg.depts删除的对象  theIndex为当前索引
        this.allDeptMsg.users.splice(theIndex, 1);
        for (let i = 0; i < this.allDeptMsg.userList.length; i++) {
          if (this.allDeptMsg.userList[i].name == name) {
            this.allDeptMsg.userList[i].show = false;
          }
        }

        this.$store.commit('SET_MSG', this.allDeptMsg);
      },
      hq() {
        console.log(this.$store.state.allDept);
      }
    },
    watch: {}
  }
</script>

<style lang="less" scoped>
  .choose-dept-user > div {
    overflow-y: auto;
  }

  .chooseMsg {
    width: 100%;
    height: 70px;
    overflow-y: auto;
    border: 1px solid #ccc;
    margin-bottom: 10px;

    span {
      text-decoration: none;
      display: inline-block;
      height: 25px;
      padding: 0 7px 0 15px;
      background-color: #fff;
      color: #666;
      text-align: center;
      line-height: 25px;
      margin-top: 3px;
      margin-left: 4px;
      border-radius: 5px;
      border: 1px solid #e9eaec;
      font-size: 12px;
      cursor: pointer;

      > i {
        font-size: 12px;
        font-style: normal;
        padding-left: 7px;
      }
    }

    span.user {
      background-color: #409eff;
      border: 1px solid #409eff;
      color: #fff;
    }

    span.dept {
      background-color: red;
      border: 1px solid red;
      color: #fff;
    }
  }

</style>
