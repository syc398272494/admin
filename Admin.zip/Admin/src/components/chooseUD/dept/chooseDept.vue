<!--
    * 选择部门组件
    * sendData 父组件传值给 选部门子组件
    * activeName   1 多选部门   2 多选人   3 单选部门   4 单选人        单选 和多选不能一起使用
    * url   请求地址
    * depts 选中的部门列表
    * users 选中的人员列表
    * selDeptId 选择人员时 当前人员所属部门的id  
    * deptList 部门的数据源 数组
    * userList 人员的数据源 数组    可通过 selDeptId  来获取人员数据
    * vuexSet  vuex里定义的 设置 数据的方法名
-->
<template>
    <div class="chooseDept" :class="{'dept':allDate.activeName==1||allDate.activeName==3}">
        <div v-if="allDate.activeName==1||allDate.activeName==3">
            <p v-for="(item,index) in allDate.deptList" :key="item.deptId" @click="choose(item.deptId,index,item)" :class="{'gary':item.show}">
                <span>{{item.name}}</span> 
                <img v-if="item.show&&allDate.activeName==1" src="../../../assets/img/selection.png" alt=""> 
                <img v-else-if="!item.show&&allDate.activeName==1" src="../../../assets/img/unchecked.png" alt=""> 
            </p>
        </div>
        <div v-else-if="allDate.activeName==2||allDate.activeName==4">
            <p v-for="(item,index) in allDate.deptList" :key="item.deptId" @click="choose(item.deptId,index,item)" :class="{'gary':item.deptId==allDate.selDeptId}">
                <span>{{item.name}}</span> 
            </p>
        </div>
    </div>
</template>
<script>
import {mapGetters} from 'vuex'
import { getDepts } from '@/api/getDeptUser'   //获取部门等数据
    export default {
        name: "chooseDept",
        props:['sendData'],
        data(){
            return{
                
            }
        },
        computed:mapGetters({
            allDate:'GET_MSG'  //获取vuex 里面存储的值
        }),
        mounted(){
            var _this=this;
            //this.$store.commit('SET_MSG',this.allDeptMsg);
            this.getDept();   //获取部门数据 并更新到vuex
        },
        methods:{
            getDept(){   //获取部门  并更新给vuex
                this.sendData.deptList=[
                  {deptId: 1, name: '研发五部', show: false, value: '研发五部', label: '研发五部',},
                  {deptId: 2, name: '研发三部', show: false, value: '研发三部', label: '研发三部'},
                  {deptId: 3, name: '测试部', show: false, value: '测试部', label: '测试部'},
                  {deptId: 4, name: '销售部', show: false, value: '销售部', label: '销售部'},
                  {deptId: 5, name: '产品部', show: false, value: '产品部', label: '产品部'},
                  {deptId: 6, name: '总裁班', show: false, value: '总裁班', label: '总裁班'},
                  {deptId: 7, name: '研发一部', show: false, value: '研发一部', label: '研发一部'},
                  {deptId: 8, name: '研发二部', show: false, value: '研发二部', label: '研发二部'},
                  {deptId: 9, name: '研发四部', show: false, value: '研发四部', label: '研发四部'},
                  {deptId: 10, name: '财务部', show: false, value: '财务部', label: '财务部'},
                ];
                // this.$store.commit(this.sendData.vuexSet,this.sendData);//
                getDepts('','').then((res)=>{
                    //console.log(res)
                }).catch((error)=>{
                    //console.log(error);
                })
            },
            choose(id,index,items){   //点击选择部门
                var _this=this;
                if(_this.sendData.activeName==1){   //状态为 1  选择部门
                    _this.sendData.deptList[index].show=!_this.sendData.deptList[index].show;
                    if(_this.sendData.deptList[index].show==true){   //若值为true 则将数组添加到 sendData.depts数组里面
                        _this.sendData.depts.push(_this.sendData.deptList[index]);
                      this.$store.commit(this.sendData.vuexSet,this.sendData);
                    }else{       //若值为false 则将数组 sendData.depts里删除当前数据
                        this.sendData.depts.map((item,index)=>{
                            if (item.name === items.name) {
                                this.sendData.depts.splice(index, 1);
                            }
                          this.$store.commit(this.sendData.vuexSet,this.sendData);
                        })
                    }
                    // this.$store.commit(this.sendData.vuexSet,this.sendData);  //将改变的值 更新到vuex
                }else if(_this.sendData.activeName==2||_this.sendData.activeName==4){
                    this.sendData.selDeptId=id;
                        this.$emit("selDeptId",this.sendData.selDeptId);
                        this.$store.commit('SET_MSG',this.sendData);
                }else if(_this.sendData.activeName==3){    //单选部门
                     _this.sendData.deptList[index].show=!_this.sendData.deptList[index].show;
                    if(_this.sendData.deptList[index].show==true){   //若值为true 则将数组添加到 sendData.depts数组里面
                        this.sendData.deptList.map((item,indexs)=>{
                            if (index != indexs) {
                                this.sendData.deptList[indexs].show=false;
                            }
                        })
                        _this.sendData.depts=[];
                        _this.sendData.depts.push(_this.sendData.deptList[index])
                    }else{       //若值为false 则将数组 sendData.depts里删除当前数据
                        this.sendData.depts.map((item,index)=>{
                            if (item.name === items.name) {
                                this.sendData.depts.splice(index, 1);
                            }
                        })
                    }
                    this.$store.commit(this.sendData.vuexSet,this.sendData);  //将改变的值 更新到vuex
                }
            }
        }
    }
</script>

<style lang="less" scoped>
    .chooseDept{
        float: left;
        width: 49%;
        margin-right: 10px;
        font-size: 14px;
        color: #666;
       >div{
           min-height: 100px;
            max-height: 350px;
            overflow-y: scroll;
            border: 1px solid #ccc;
            background-color: #fff;
            
            >p{
                padding: 0 15px;
                box-sizing: border-box;
                margin: 0;
                cursor: pointer;
                height: 45px;
                line-height: 45px;
                border-bottom: 1px solid #ccc;
                img{
                    width: 17px;
                    margin-top: 14px;
                    float: right;
                }
            }
            >p.gary{
               background-color:#ddd; 
            }
            >p:hover{
                background-color: #efefef;
            }
       }
    }
    .chooseDept.dept{
         width: 100%;
    }

</style>
